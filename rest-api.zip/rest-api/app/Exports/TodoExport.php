<?php 
namespace App\Exports;

use App\Models\Todolist;
use Maatwebsite\Excel\Facades\Excel;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Events\AfterSheet;

class TodoExport implements FromCollection, WithHeadings, WithMapping, WithEvents
{
    protected $filtered;

    public function __construct($filtered)
    {
        $this->filtered = $filtered;
    }

    public function collection()
    {
        return $this->filtered;
    }

    public function headings(): array
    {
        return ['Title', 'Assignee', 'Due Date', 'Time Tracked', 'Status', 'Priority'];
    }

    public function map($todo): array
    {
        return [
            $todo->title,
            $todo->assignee,
            $todo->due_date,
            $todo->time_tracked,
            $todo->status,
            $todo->priority,
        ];
    }

    public function registerEvents(): array
    {
        return [
            AfterSheet::class => function (AfterSheet $event) {
                $rowCount = count($this->filtered) + 2;
                $event->sheet->setCellValue('A' . $rowCount, 'Total');
                $event->sheet->setCellValue('B' . $rowCount, count($this->filtered));
                $event->sheet->setCellValue('D' . $rowCount, $this->filtered->sum('time_tracked'));
            }
        ];
    }
}
