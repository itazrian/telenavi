<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\Todolist;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use App\Exports\TodoExport;
use Maatwebsite\Excel\Facades\Excel;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Events\AfterSheet;

class TodoController extends Controller
{
    public $successStatus = 200;

    public function create(Request $request){

        $validator = Validator::make($request->all(), [
            'title' => 'required|string',
            'due_date' => 'required|date',
            'priority' => 'required|in:low,medium,high',
            'status' => 'nullable|in:pending,open,in_progress,completed',
        ]);

        if ($validator->fails()) {
            return response()->json([
                'response' => [],
                'metadata' => ['message' => $validator->errors(), 'code'=>422],
            ], 422);
        }

        // validation 1. due_date cannot be in the past
        if (strtotime($request->due_date) < strtotime(date('Y-m-d'))) {
            return response()->json([
                'response' => [],
                'metadata' => ['message' => 'Due date cannot be in the past', 'code' => 422],
            ], 422);
        }

        // validation 2. status default to pending if not provided
        $status = $request->status ?? 'pending';

        $todo = Todolist::create([
            'title' => $request->title,
            'assignee' => $request->assignee,
            'due_date' => $request->due_date,
            'time_tracked' => $request->time_tracked ?? 0,
            'status' => $status,
            'priority' => $request->priority,
        ]);

        $response = [
            'response' => [
                'title' => $todo->title,
                'assignee' => $todo->assignee,
                'due_date' => $todo->due_date,
                'time_tracked' => $todo->time_tracked,
                'status' => $todo->status,
                'priority' => $todo->priority,
            ],
            'metadata' => ['message' => 'Success', 'code'=>200]
        ];

        return Response()->json($response, $this->successStatus);
    }

    public function exportToExcel(Request $request){
        $query = Todolist::query();
        // Filter title (like)
        if ($request->filled('title')) {
            $query->where('title', 'like', '%' . $request->title . '%');
        }

        // Filter assignee (multiple)
        if ($request->filled('assignee')) {
            $assignees = explode(',', $request->assignee);
            $query->whereIn('assignee', $assignees);
        }

        // Filter due_date (range)
        if ($request->filled('start') && $request->filled('end')) {
            $query->whereBetween('due_date', [$request->start, $request->end]);
        }

        // Filter time_tracked (range)
        if ($request->filled('min') && $request->filled('max')) {
            $query->whereBetween('time_tracked', [$request->min, $request->max]);
        }

        // Filter status (multiple)
        if ($request->filled('status')) {
            $statuses = explode(',', $request->status);
            $query->whereIn('status', $statuses);
        }

        // Filter priority (multiple)
        if ($request->filled('priority')) {
            $priorities = explode(',', $request->priority);
            $query->whereIn('priority', $priorities);
        }

        $todos = $query->get();

        return Excel::download(new TodoExport($todos), 'todolist-report.xlsx');
    }

    public function getChart(Request $request){
        $type = $request->query('type');

        switch ($type) {
            case 'status':
                $data = Todolist::selectRaw('status, COUNT(*) as total')
                        ->groupBy('status')
                        ->pluck('total', 'status');

                return response()->json([
                    'status_summary' => $data
                ]);

            case 'priority':
                $data = Todolist::selectRaw('priority, COUNT(*) as total')
                        ->groupBy('priority')
                        ->pluck('total', 'priority');

                return response()->json([
                    'priority_summary' => $data
                ]);

            case 'assignee':
                $users = Todolist::select('assignee')
                        ->whereNotNull('assignee')
                        ->distinct()
                        ->pluck('assignee');

                $data = [];
                foreach ($users as $user) {
                    $data[$user] = [
                        'total_todos' => Todolist::where('assignee', $user)->count(),
                        'total_pending_todos' => Todolist::where('assignee', $user)
                            ->where('status', 'pending')->count(),
                        'total_timetracked_completed_todos' => Todolist::where('assignee', $user)
                            ->where('status', 'completed')
                            ->sum('time_tracked'),
                    ];
                }

                return response()->json([
                    'assignee_summary' => $data
                ]);

            default:
                return response()->json([
                    'message' => 'Invalid type parameter. Gunakan: status, priority atau assignee.'
                ], 400);
        }
    }

}